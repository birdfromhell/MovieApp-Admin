<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!doctype html>
<html lang="en">

    <head>
    
        <meta charset="utf-8">
        <title>Dashboard | Dooo - Movie & Web Series Portal App</title>

        <?php include("partials/header.php"); ?>
    
    </head>

    <body data-sidebar="dark">

        <!-- Begin page -->
        <div id="layout-wrapper">

            
            <?php include("partials/topbar.php"); ?>

            
            <?php include("partials/sidebar.php"); ?>
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

            	<div class="page-content">

            		<div class="container-fluid">



            			<!-- start page title -->

            			<div class="row align-items-center">

            				<div class="col-sm-6">

            					<div class="page-title-box">

            						<h4 class="font-size-18">All Web Series</h4>

            						<ol class="breadcrumb mb-0">

            							<li class="breadcrumb-item"><a href="javascript: void(0);">Dooo</a></li>

            							<li class="breadcrumb-item"><a href="javascript: void(0);">Web Series</a></li>

            							<li class="breadcrumb-item active">All Web Series</li>

            						</ol>

            					</div>

            				</div>

            			</div>

            			<!-- end page title -->

                        <div class="row">
                        	<div class="col-12">
                        		<div class="card">
                        			<div class="card-body">
                        				<table id="datatable" class="table table-striped"
                        					style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        					<thead>
                        						<tr>
                        							<th>#</th>
                        							<th>##</th>
                        							<th>Thumbnail</th>
                        							<th>Name</th>
                        							<th>Description</th>
                        							<th>Status</th>
                        						</tr>
                        					</thead>
                        				</table>
                        			</div>
                        		</div>
                        	</div> <!-- end col -->

                        </div> <!-- end row -->
                       

            		</div> <!-- container-fluid -->

            	</div>


            	<?php include("partials/footer_rights.php"); ?>


            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <?php include("partials/footer.php"); ?>

    <script>
        $('#datatable').dataTable({
            "order": [],
            "ordering": false,
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": "<?= site_url('Admin_api/get_all_webseries') ?>",
                "type":"GET",
            },
            "columns": [{
                    "data": "1",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {
                    "data": "2",
                    render: function (data) {
                        return '<div class="btn-group mr-1 mt-2"> <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Options <i class="mdi mdi-chevron-down"></i></button> <div class="dropdown-menu" style=""> <a class="dropdown-item" onclick="Edit_Movie(' +
                            data +
                            ')" href="#">Edit WebSeries</a> <a class="dropdown-item" onclick="Manage_Seasons(' +
                            data +
                            ')" href="#">Manage Seasons</a> <a class="dropdown-item" id="Delete" onclick="Delete_Data(' +
                            data +
                            ')" href="#">Delete</a> <div class="dropdown-divider"></div> <a class="dropdown-item" href="notification_web_series.php?id=' +
                            data + '">Send Push Notification</a> <a class="dropdown-item" onclick="telegramNotify(' +
                            data + ')">Send Telegram Notification</a> </div> </div>';
                    }
                },
                {
                    "data": "3",
                    render: function (data) {
                        return '<img class="img-fluid" height="100" width="80" src=' + data +
                            ' data-holder-rendered="true">';
                    }
                },
                {
                    "data": "4"
                },
                {
                    "data": "5"
                },
                {
                    "data": "6",
                    render: function (data) {
                        if (data == 0) {
                            return '<span class="badge bg-danger">UnPublished</span>';
                        } else if (data == 1) {
                            return '<span class="badge bg-success">Published</span>';
                        }
                    }
                }
            ]
    
        });

        function Delete_Data(ID) {

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#34c38f",
                cancelButtonColor: "#f46a6a",
                confirmButtonText: "Yes, delete it!"
            }).then(function (result) {
                if (result.value) {
                    var jsonObjects = {
                        "WebSeriesID": ID
                    };
            
                    $.ajax({
                        type: 'POST',
                        url: "<?= site_url('Admin_api/delete_web_series') ?>",
                        data: jsonObjects,
                        dataType: 'text',
                        success: function (response) {
                            if (response) {
                                swal.fire({
                                    title: 'Successful!',
                                    text: 'Web Series Deleted Successfully!',
                                    icon: 'success',
                                    showCancelButton: false,
                                    confirmButtonColor: '#556ee6',
                                    cancelButtonColor: "#f46a6a"
                                }).then(function () {
                                    location.reload();
                                });
                            } else {
                                swal.fire({
                                    title: 'Error',
                                    text: 'Something Went Wrong :(',
                                    icon: 'error'
                                }).then(function () {
                                    location.reload();
                                });
                            }
            
                        }
            
                    });
            
                }
            
            });
            
        }

        function Edit_Movie(ID) {
            window.location.assign("edit_webSeries/" + ID);
        }

        function Manage_Seasons(ID) {
            window.location.assign("manage_seasons/" + ID);
        }
    </script>