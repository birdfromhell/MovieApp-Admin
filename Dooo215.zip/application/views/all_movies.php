<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!doctype html>
<html lang="en">

    <head>
    
        <meta charset="utf-8">
        <title>Dashboard | Dooo - Movie & Web Series Portal App</title>

        <?php include("partials/header.php"); ?>
    
    </head>

    <body data-sidebar="dark">

        <!-- Begin page -->
        <div id="layout-wrapper">

            
            <?php include("partials/topbar.php"); ?>

            
            <?php include("partials/sidebar.php"); ?>
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

            	<div class="page-content">
            		<div class="container-fluid">



            			<!-- start page title -->

            			<div class="row align-items-center">

            				<div class="col-sm-6">

            					<div class="page-title-box">

            						<h4 class="font-size-18">All Movies</h4>

            						<ol class="breadcrumb mb-0">

            							<li class="breadcrumb-item"><a href="javascript: void(0);">Dooo</a></li>

            							<li class="breadcrumb-item"><a href="javascript: void(0);">Movies</a></li>

            							<li class="breadcrumb-item active">All Movies</li>

            						</ol>

            					</div>

            				</div>

            			</div>

            			<!-- end page title -->

            			<div class="row">

            				<div class="col-12">

            					<div class="card">

            						<div class="card-body">

            							<table id="datatable" class="table table-striped"
            								style="border-collapse: collapse; border-spacing: 0; width: 100%;">

            								<thead>

            									<tr>

            										<th>#</th>

            										<th>##</th>

            										<th>Thumbnail</th>

            										<th>Name</th>

            										<th>Description</th>

            										<th>Status</th>

            									</tr>

            								</thead>

            							</table>



            						</div>

            					</div>

            				</div> <!-- end col -->

            			</div> <!-- end row -->



            		</div> <!-- container-fluid -->
            	</div>
            	<!-- End Page-content -->


            	<?php include("partials/footer_rights.php"); ?>


            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <?php include("partials/footer.php"); ?>

        <script>
             $('#datatable').dataTable({
                "order": [],
                "ordering": false,
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "<?= site_url('Admin_api/getAllMovie') ?>",
                    "type":"GET",
                },
                "columns": [{
                        "data": "1",
                        render: function (data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        }
                    },
                    {
                        "data": "2",
                        render: function (data) {
                            return '<div class="d-none d-sm-block"><div class="dropdown d-inline-block"><a class="btn btn-secondary dropdown-toggle" href="#" role="button"id="dropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true"aria-expanded="false">Options <i class="mdi mdi-chevron-down"></i></a><div class="dropdown-menu" aria-labelledby="dropdownMenuLink"><a class="dropdown-item" href="<?php echo base_url(); ?>editMovie/' +
                                data + '">Edit Movie</a><a class="dropdown-item" href="<?= site_url('manage_movie_links') ?>/' +
                                data + '">Manage Videos</a><a class="dropdown-item" href="<?= site_url('manage_movie_Download_links') ?>/' +
                                data + '">Manage Downloads</a><a class="dropdown-item" onclick="DeleteMovie(' +
                                data + ')">Delete</a><div class="dropdown-divider"></div><a class="dropdown-item" href="notification_movie.php?id=' +
                                data + '">Send Push Notification</a><a class="dropdown-item" onclick="telegramNotify(' +
                                data + ')">Send Telegram Notification</a></div></div></div>';
                        }
                    },
                    {
                        "data": "3",
                        render: function (data) {
                           return '<img class="img-fluid" height="100" width="80" src='+ data +' data-holder-rendered="true">';
                        }
                    },
                    {
                        "data": "4"
                    },
                    {
                        "data": "5"
                    },
                    {
                        "data": "6",
                        render: function (data) {
                            if (data == 0) {
                                return '<span class="badge bg-danger">UnPublished</span>';
                            } else if (data == 1) {
                                return '<span class="badge bg-success">Published</span>';
                            }
                        }
                    }
                ]
            });

            function DeleteMovie(movieID) {
                Swal.fire({
                    title: "Are you sure?",
                    text: "You won't be able to revert this!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#34c38f",
                    cancelButtonColor: "#f46a6a",
                    confirmButtonText: "Yes, delete it!"
                }).then(function (result) {
                    if (result.value) {
                        $.ajax({
                          url: '<?= site_url('Admin_api/deleteMovie') ?>',
                          type: 'POST',
				          data : { movieID : movieID },
                          dataType:'json',
                            success: function(result){
				        		if(result) {
				        			swal.fire({
                                        title: 'Successful!',
                                        text: 'Movie Deleted successfully!',
                                        icon: 'success',
                                        showCancelButton: false,
                                        confirmButtonColor: '#556ee6',
                                        cancelButtonColor: "#f46a6a"
                                    }).then(function () {
                                        location.reload();
                                    });
				        		}
                            }
                        });
                    }
                });
            }
            
        </script>